import java.io.*;
import java.nio.file.*;
import java.util.Scanner;

public class Main {
    private static final String JOURNAL_FILE = "filesystem.journal";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Seja bem vindo! Este é um Simulador de Sistema de arquivos!");
        System.out.println("Digite 'exit' se deseja sair.");

        while (true) {
            System.out.print("> ");
            String command = scanner.nextLine();
            if (command.equalsIgnoreCase("exit")) break;
            commandProcessing(command);
        }
        scanner.close();
    }

    private static void commandProcessing(String command) {
        try {
            String[] parts = command.split(" ");
            String operation = parts[0];
            switch (operation) {
                case "copy":
                    copyArchive(parts[1], parts[2]);
                    break;
                case "rm":
                    deleteArchive(parts[1]);
                    break;
                case "mkdir":
                    createDirectory(parts[1]);
                    break;
                case "rmdir":
                    deleteDirectory(parts[1]);
                    break;
                case "rename":
                    rename(parts[1], parts[2]);
                    break;
                case "ls":
                    listDirectory(parts[1]);
                    break;
                default:
                    System.out.println("Este comando não existe!");
            }
        } catch (Exception e) {
            System.out.println("Não foi possível processar este comando: " + e.getMessage());
        }
    }

    private static void copyArchive(String beginning, String ending) throws IOException {
        Files.copy(Paths.get(beginning), Paths.get(ending), StandardCopyOption.REPLACE_EXISTING);
        Journaling("copy " + beginning + " " + ending);
        System.out.println("O arquivo foi copiado com sucesso.");
    }

    private static void deleteArchive(String pathway) throws IOException {
        Files.delete(Paths.get(pathway));
        Journaling("rm " + pathway);
        System.out.println("O arquivo foi apagado com sucesso.");
    }

    private static void createDirectory(String pathway) throws IOException {
        Files.createDirectories(Paths.get(pathway));
        Journaling("mkdir " + pathway);
        System.out.println("O diretório foi criado com sucesso.");
    }

    private static void deleteDirectory(String pathway) throws IOException {
        Path dir = Paths.get(pathway);
        if (!Files.exists(dir)) {
            System.out.println("Não foi possível encontrar o diretório: " + pathway);
            return;
        }

        Files.walk(dir)
                .sorted((a, b) -> b.compareTo(a)) 
                .forEach(path -> {
                    try {
                        Files.delete(path);
                        Journaling("deletar " + path);
                    } catch (IOException e) {
                        System.out.println("Erro na hora de apagar: " + path);
                    }
                });

        System.out.println("O diretório foi apagado com sucesso: " + pathway);
    }

    private static void rename(String pathway, String newPathway) throws IOException {
        Path beginning = Paths.get(pathway);
        Path ending = Paths.get(newPathway);
        Files.move(beginning, ending, StandardCopyOption.REPLACE_EXISTING);
        Journaling("renomear " + pathway + " " + newPathway);
        System.out.println("Renomeado então para: " + newPathway);
    }

    private static void listDirectory(String pathway) throws IOException {
        Files.list(Paths.get(pathway)).forEach(System.out::println);
    }

    private static void Journaling(String operation) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(JOURNAL_FILE, true))) {
            writer.write(operation);
            writer.newLine();
        }
    }
}
